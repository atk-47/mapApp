import React, { useState } from 'react';
import './App.css';
import Map from './components/Map';
import Maps from './components/Maps';


const apikey = 'hkOwg_vp1p9zdrZsUZgAi6w7KG6NDz_WMvoy5CoBgXo';

const userPosition = { lat: 17.5449, lng: 78.5718 };

// const restaurantList = [
//       {
//           "title": "GC Hospital",
//           "id": "here:pds:place:356tepgg-df84b6cea08e4cfaa128a4ca741c908c",
//           "language": "en",
//           "resultType": "place",
//           "address": {
//               "label": "GC Hospital, CRPF Hakimpet, Hakimpet, Secunderabad 500078, India",
//               "countryCode": "IND",
//               "countryName": "India",
//               "stateCode": "TS",
//               "state": "Telangana",
//               "county": "Medchal Malkajgiri",
//               "city": "Secunderabad",
//               "district": "Hakimpet",
//               "subdistrict": "CRPF Hakimpet",
//               "postalCode": "500078"
//           },
//           "position": {
//               "lat": 17.53789,
//               "lng": 78.56285
//           },
//           "access": [
//               {
//                   "lat": 17.53828,
//                   "lng": 78.56286
//               }
//           ],
//           "distance": 1232,
//           "categories": [
//               {
//                   "id": "800-8000-0159",
//                   "name": "Hospital",
//                   "primary": true
//               },
//               {
//                   "id": "700-7200-0272",
//                   "name": "Healthcare and Healthcare Support Services"
//               }
//           ]
//       }
//   ]

const restaurantList = [
  {
    name: "Punjabi Haveli",
    location: { lat: 17.57242794740273, lng: 78.5594516901389 },
    //17.57242794740273, 78.5594516901389
  },
  {
    name: "Tandoor",
    location: { lat: 17.573513857530074, lng: 78.56649902155148 },
    //17.573513857530074, 78.56649902155148
  },
  {
    name: "Alankrita",
    location: { lat: 64.1475, lng: -21.9347 },
  },
  {
    name: "Leonia Restaurant",
    location: { lat: 64.1494, lng: -21.9337 },
  },
  {
    name: "Punjabi Haveli",
    location: { lat: 17.57242794740273, lng: 78.5594516901389 },
    //17.57242794740273, 78.5594516901389
  },
  {
    name: "Tandoor",
    location: { lat: 17.573513857530074, lng: 78.56649902155148 },
    //17.573513857530074, 78.56649902155148
  },
  {
    name: "Alankrita",
    location: { lat: 64.1475, lng: -21.9347 },
  },
  {
    name: "Leonia Restaurant",
    location: { lat: 64.1494, lng: -21.9337 },
  }
];


  function RestaurantEntry(props) {
    const handleClick = () => {
      props.onClickHandler(props.data.location);
    };
    // Add basic styling for each restaurant entry
    const entryStyle = {
      display: "inline-block",
      padding: "10px",
      margin: "5px",
      border: "1px solid gray",
      borderRadius: "5px",
      cursor: "pointer",
    };
 
    return (
      <div style={entryStyle} onClick={handleClick}>
        {props.data.name}
      </div>
    );
  }

  function RestaurantList(props) {
    const entries = props.list;
    const list = entries.map((entry) => {
      return <RestaurantEntry data={entry} onClickHandler={props.onClickHandler} key={Math.random()}></RestaurantEntry>
    });
    return (
      <div id="restaurant-list" style={ {'display': 'grid'} } >
      {list}
      </div>
    )
  }
 

  function App() {
    const [restaurantPosition, setRestaurantPosition] = useState(null);
 
    const onClickHandler_ = (location) => {
      setRestaurantPosition(location);
    };
 
    return (
      <div>
        <RestaurantList list={restaurantList} onClickHandler={onClickHandler_} />
        <Map
          apikey={apikey}
          userPosition={userPosition}
          restaurantPosition={restaurantPosition}
        />
      </div>
    );
  }
 

export default App;
